﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp3
{
    public partial class Form2 : Form
    {
        private Random _random = new Random();

       
        public int SelectedNumber { get; private set; }

        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SelectedNumber = _random.Next(1, 51);
            
            this.DialogResult = DialogResult.OK; 
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SelectedNumber = _random.Next(1, 101);
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SelectedNumber = _random.Next(1, 151);
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}