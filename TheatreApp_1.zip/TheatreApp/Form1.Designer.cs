﻿namespace TheatreApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            ButtonRefresh_Click = new Button();
            ButtonDelete_Click = new Button();
            btnSaveChanges_Click = new Button();
            btnSearch_Click = new Button();
            btnClear_Click = new Button();
            dataGridView1 = new DataGridView();
            label1 = new Label();
            txtSearch = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(231, 277);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 0;
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // ButtonRefresh_Click
            // 
            ButtonRefresh_Click.Location = new Point(231, 317);
            ButtonRefresh_Click.Name = "ButtonRefresh_Click";
            ButtonRefresh_Click.Size = new Size(75, 23);
            ButtonRefresh_Click.TabIndex = 1;
            ButtonRefresh_Click.Text = "button2";
            ButtonRefresh_Click.UseVisualStyleBackColor = true;
            ButtonRefresh_Click.Click += ButtonRefresh_Click_Click;
            // 
            // ButtonDelete_Click
            // 
            ButtonDelete_Click.Location = new Point(231, 357);
            ButtonDelete_Click.Name = "ButtonDelete_Click";
            ButtonDelete_Click.Size = new Size(75, 23);
            ButtonDelete_Click.TabIndex = 2;
            ButtonDelete_Click.Text = "button2";
            ButtonDelete_Click.UseVisualStyleBackColor = true;
            ButtonDelete_Click.Click += ButtonDelete_Click_Click;
            // 
            // btnSaveChanges_Click
            // 
            btnSaveChanges_Click.Location = new Point(260, 406);
            btnSaveChanges_Click.Name = "btnSaveChanges_Click";
            btnSaveChanges_Click.Size = new Size(75, 23);
            btnSaveChanges_Click.TabIndex = 3;
            btnSaveChanges_Click.Text = "button2";
            btnSaveChanges_Click.UseVisualStyleBackColor = true;
            btnSaveChanges_Click.Click += btnSaveChanges_Click_Click;
            // 
            // btnSearch_Click
            // 
            btnSearch_Click.Location = new Point(453, 340);
            btnSearch_Click.Name = "btnSearch_Click";
            btnSearch_Click.Size = new Size(75, 23);
            btnSearch_Click.TabIndex = 4;
            btnSearch_Click.Text = "button2";
            btnSearch_Click.UseVisualStyleBackColor = true;
            btnSearch_Click.Click += btnSearch_Click_Click;
            // 
            // btnClear_Click
            // 
            btnClear_Click.Location = new Point(453, 385);
            btnClear_Click.Name = "btnClear_Click";
            btnClear_Click.Size = new Size(75, 23);
            btnClear_Click.TabIndex = 5;
            btnClear_Click.Text = "button2";
            btnClear_Click.UseVisualStyleBackColor = true;
            btnClear_Click.Click += btnClear_Click_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(39, 23);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(240, 150);
            dataGridView1.TabIndex = 6;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(415, 50);
            label1.Name = "label1";
            label1.Size = new Size(38, 15);
            label1.TabIndex = 7;
            label1.Text = "label1";
            label1.Click += label1_Click;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(408, 142);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(100, 23);
            txtSearch.TabIndex = 8;
            txtSearch.TextChanged += txtSearch_TextChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txtSearch);
            Controls.Add(label1);
            Controls.Add(dataGridView1);
            Controls.Add(btnClear_Click);
            Controls.Add(btnSearch_Click);
            Controls.Add(btnSaveChanges_Click);
            Controls.Add(ButtonDelete_Click);
            Controls.Add(ButtonRefresh_Click);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button ButtonRefresh_Click;
        private Button ButtonDelete_Click;
        private Button btnSaveChanges_Click;
        private Button btnSearch_Click;
        private Button btnClear_Click;
        private DataGridView dataGridView1;
        private Label label1;
        private TextBox txtSearch;
    }
}
